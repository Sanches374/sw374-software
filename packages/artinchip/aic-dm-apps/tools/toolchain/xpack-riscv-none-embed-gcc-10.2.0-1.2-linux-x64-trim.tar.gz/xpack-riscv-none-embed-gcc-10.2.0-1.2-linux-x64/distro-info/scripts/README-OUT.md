# xPack GNU RISC-V Embedded GCC

The **xPack GNU RISC-V Embedded GCC** (formely GNU MCU Eclipse RISC-V GCC)
is the **xPack** version of the **GNU RISC-V Embedded GCC** toolchain
maintained by **SiFive**.

For more details, please read the corresponding release pages:

- <https://xpack.github.io/riscv-none-embed-gcc/releases/>
- <https://github.com/sifive/freedom-tools/releases>

Thank you for using open source software,

Liviu Ionescu
