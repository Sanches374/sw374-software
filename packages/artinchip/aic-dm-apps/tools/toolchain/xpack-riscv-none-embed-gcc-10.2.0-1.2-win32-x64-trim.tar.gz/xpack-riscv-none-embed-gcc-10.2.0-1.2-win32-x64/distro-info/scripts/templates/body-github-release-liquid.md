![Github Releases (by Release)](https://img.shields.io/github/downloads/xpack-dev-tools/riscv-none-embed-gcc-xpack/v{{ RELEASE_VERSION }}/total.svg)

Version **{{ RELEASE_VERSION }}** is a maintenance release of the **xPack RISC-V Embedded GCC** package; it updates to the latest upstream master.

Or (TODO: edit!):

Version **{{ RELEASE_VERSION }}** is a new release of the **xPack RISC-V Embedded GCC** package, following the upstream SiFive [release](https://github.com/sifive/freedom-tools/releases/) v2020.12.0 from DATE (TODO: edit).

[Continue reading »](TODO: edit, add URL!)

_At this moment the binaries are provided for tests only!_
